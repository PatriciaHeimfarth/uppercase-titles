=== Uppercase Titles ===
Contributors: patriciaheimfarth
Tags: titles, formatting, format title, uppercase, uppercase titles
Tested up to: 5.6
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin applies an uppercase formatting on all page titles and post titles after activation.

== Description ==
This plugin applies an uppercase formatting on all page titles and post titles after activation. After deactivation all is formatted in the original form.  
It is discussed if uppercase titles are helping with SEO. For a blog or website with a lot of posts it is much easier to activate a plugin instead of changing everything manually.

== Installation ==
The titles are changed directly after installing and activating the plugin. There are no further settings needed. 